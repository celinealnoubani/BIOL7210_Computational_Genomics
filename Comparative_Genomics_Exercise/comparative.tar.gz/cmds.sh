# Create a main directory for the HW assignment
mkdir Comp_Genomics_HW

# Change into the HW directory
cd Comp_Genomics_HW

# Create a directory to store raw FASTQ files
mkdir Raw_FastQs

# Change into the Raw_FastQs directory
cd Raw_FastQs

# Activate the Conda environment "ex3" that contains the necessary bioinformatics tools
conda activate ex3

# Download raw sequence data from NCBI SRA for each accession using prefetch
for accession in SRR1556294 SRR1556293 SRR1556289 SRR1556296 SRR1556290 SRR1556291 SRR1556297 SRR1556295 SRR1556288 SRR1553827; do
    prefetch "${accession}"
done

# Convert SRA files to FASTQ format using fasterq-dump
for accession in SRR1556294 SRR1556293 SRR1556289 SRR1556296 SRR1556290 SRR1556291 SRR1556297 SRR1556295 SRR1556288 SRR1553827; do
  fasterq-dump \
   "${accession}" \
   --outdir . \
   --split-files \
   --skip-technical
done

# Compress the resulting FASTQ files using pigz (parallel gzip) with maximum compression (-9)
pigz -9 *.fastq

# Go back to the main directory
cd ..

# Create a directory for storing the cleaned FASTQ files
mkdir Cleaned_FastQs

# Change into the Cleaned_FastQs directory
cd Cleaned_FastQs

# Dry-run for running fastp 
# This loop prints the fastp command that would process each pair of raw FASTQ files
for read in /mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Raw_FastQs/*_1.fastq.gz; do 
  sample="$(basename ${read} _1.fastq.gz)"  # Extract the sample name by stripping the '_1.fastq.gz' suffix
  echo fastp \
    -i "${read}" \
    -I "${read%_1.fastq.gz}_2.fastq.gz" \
    -o "/mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Cleaned_FastQs/${sample}.R1.fq.gz" \
    -O "/mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Cleaned_FastQs/${sample}.R2.fq.gz" \
    --json "/mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Cleaned_FastQs/${sample}.json" \
    --html "/mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Cleaned_FastQs/${sample}.html" 
done

# After verifying that the printed commands are correct, remove the "echo" to execute fastp:
for read in /mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Raw_FastQs/*_1.fastq.gz; do 
  sample="$(basename ${read} _1.fastq.gz)"  # Extract sample name from the filename
  fastp \
    -i "${read}" \                                  # Input file for read 1
    -I "${read%_1.fastq.gz}_2.fastq.gz" \             # Input file for read 2, by replacing _1 with _2
    -o "/mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Cleaned_FastQs/${sample}.R1.fq.gz" \
    -O "/mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Cleaned_FastQs/${sample}.R2.fq.gz" \
    --json "/mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Cleaned_FastQs/${sample}.json" \
    --html "/mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Cleaned_FastQs/${sample}.html"
done

# List all compressed files to verify the output from read cleaning
ls *.gz

# Go back to the main project directory
cd ..

# Create a directory for genome assemblies
mkdir Assemblies

# Change into the Assemblies directory
cd Assemblies 

# For each cleaned read file (R1), run SKESA to build genome assemblies
# reads: Provides a comma-separated pair of R1 and R2 files for each sample
# cores 4: Use 4 CPU cores
# min_contig 1000: Only report contigs longer than 1000 bp
# contigs_out: Specifies the output file name for the assembly
for read in /mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Cleaned_FastQs/*.R1.fq.gz; do
  sample="$(basename ${read} .R1.fq.gz)"  # Extract sample name by removing '.R1.fq.gz'
  skesa \
   --reads "${read}","${read%R1.fq.gz}R2.fq.gz" \
   --cores 4 \
   --min_contig 1000 \
   --contigs_out /mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Assemblies/"${sample}".fna
done

# List all the assembled genome files in .fna format to verify assembly success
ls *.fna

# Create a new Conda environment and install Parsnp, Harvesttools, and FigTree from Bioconda for downstream analysis
conda create -n harvestsuite -c bioconda parsnp harvesttools figtree -y

# Activate the newly created 'harvestsuite' environment
conda activate harvestsuite

# Go back to the main project directory
cd ..

# Create a directory to prepare assemblies for Parsnp analysis and navigate into it
mkdir parsnp_input_assemblies
cd parsnp_input_assemblies

# Create symbolic links to the assembly files so that Parsnp can easily access them
for file in /mnt/c/Users/kayed/Documents/BIOL7210/Comp_Genomics_HW/Assemblies/*.fna; do
  ln -sv "${file}" "$(basename ${file})"
done

# Go back to the main project directory
cd ..

# Create a directory to hold the reference assembly for Parsnp
mkdir parsnp_ref_assembly

# Move SRR1556288.fna into the reference assembly directory
mv parsnp_input_assemblies/SRR1556288.fna parsnp_ref_assembly/

# Run Parsnp to generate a core genome alignment and phylogenetic tree
parsnp \
 -d parsnp_input_assemblies \
 -r parsnp_ref_assembly/SRR1556288.fna \
 -o parsnp_outdir \
 -p 4

# Launch FigTree to view and further edit the Parsnp-generated phylogenetic tree
figtree parsnp_outdir/parsnp.tree

