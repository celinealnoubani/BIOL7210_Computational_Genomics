# Exercise 5 Commands: Genotyping, Taxonomic and Quality Assessment  

# Create a top-level directory for exercise 5 and navigate into it
mkdir ex5
cd ex5

# Create a directory for the cleaning and assembly process and change into it
mkdir cleaning_assembly 
cd cleaning_assembly 

# Activate the conda environment previously made with cleaning and assembly tools already installed
conda activate genome_hw

# Check the version of fasterq-dump
fasterq-dump --version
# fasterq-dump : 3.2.0

# Create a directory to store raw data files and navigate into it
mkdir raw_data 
cd raw_data 

# Download the SRA files for the given SRR numbers
prefetch SRR27160580
prefetch SRR27160579
prefetch SRR27160578

# Convert the SRA file for SRR27160580 into paired FastQ files, skipping technical reads
fasterq-dump SRR27160580 --outdir /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data --split-files --skip-technical
# spots read      : 612,478
# reads read      : 1,224,956
# reads written   : 1,224,956

# Convert the SRA file for SRR27160579 into paired FastQ files
fasterq-dump SRR27160579 --outdir /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data --split-files --skip-technical
# spots read      : 854,792
# reads read      : 1,709,584
# reads written   : 1,709,584

# Convert the SRA file for SRR27160578 into paired FastQ files
fasterq-dump SRR27160578 --outdir /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data --split-files --skip-technical
# spots read      : 829,509
# reads read      : 1,659,018
# reads written   : 1,659,018

# List the files in the current directory to verify download and conversion
ls
# SRR27160578          SRR27160578_2.fastq  SRR27160579_1.fastq  SRR27160580          SRR27160580_2.fastq
# SRR27160578_1.fastq  SRR27160579          SRR27160579_2.fastq  SRR27160580_1.fastq

# Check the sizes of the FastQ files to ensure the expected data size
du -sh /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/*.fastq
# 403M    /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160578_1.fastq
# 404M    /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160578_2.fastq
# 410M    /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160579_1.fastq
# 410M    /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160579_2.fastq
# 306M    /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160580_1.fastq
# 307M    /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160580_2.fastq

# Compress the FastQ files using pigz 
pigz -9fv /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/*.fastq
# /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160578_1.fastq to /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160578_1.fastq.gz
# /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160578_2.fastq to /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160578_2.fastq.gz
# /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160579_1.fastq to /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160579_1.fastq.gz
# /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160579_2.fastq to /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160579_2.fastq.gz
# /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160580_1.fastq to /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160580_1.fastq.gz
# /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160580_2.fastq to /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160580_2.fastq.gz

# Display the directory tree to verify that files and structure are as expected
tree -ah /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5
# [ 512]  /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5
# └── [ 512]  cleaning_assembly
#     └── [ 512]  raw_data
#         ├── [ 512]  SRR27160578
#         │   └── [158M]  SRR27160578.sra
#         ├── [ 98M]  SRR27160578_1.fastq.gz
#         ├── [108M]  SRR27160578_2.fastq.gz
#         ├── [ 512]  SRR27160579
#         │   └── [162M]  SRR27160579.sra
#         ├── [100M]  SRR27160579_1.fastq.gz
#         ├── [112M]  SRR27160579_2.fastq.gz
#         ├── [ 512]  SRR27160580
#         │   └── [126M]  SRR27160580.sra
#         ├── [ 77M]  SRR27160580_1.fastq.gz
#         └── [ 86M]  SRR27160580_2.fastq.gz
# 6 directories, 9 files

# Go back to the cleaning_assembly directory
cd ..

# Create and navigate into a directory for raw quality assessment results
mkdir raw_qa
cd raw_qa

# Check the FastQC version
fastqc --version
# FastQC v0.12.1

# Run FastQC on all compressed FastQ files using 2 threads and output results to the specified directory
fastqc \
 --threads 2 \
 --outdir /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_qa \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/*.fastq.gz

# Display updated directory structure to confirm that quality assessment files were generated
tree -ah /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5
# [ 512]  /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5
# └── [ 512]  cleaning_assembly
#     ├── [ 512]  raw_data
#     │   ├── [ 512]  SRR27160578
#     │   │   └── [158M]  SRR27160578.sra
#     │   ├── [ 98M]  SRR27160578_1.fastq.gz
#     │   ├── [108M]  SRR27160578_2.fastq.gz
#     │   ├── [ 512]  SRR27160579
#     │   │   └── [162M]  SRR27160579.sra
#     │   ├── [100M]  SRR27160579_1.fastq.gz
#     │   ├── [112M]  SRR27160579_2.fastq.gz
#     │   ├── [ 512]  SRR27160580
#     │   │   └── [126M]  SRR27160580.sra
#     │   ├── [ 77M]  SRR27160580_1.fastq.gz
#     │   └── [ 86M]  SRR27160580_2.fastq.gz
#     └── [ 512]  raw_qa
#         ├── [632K]  SRR27160578_1_fastqc.html
#         ├── [392K]  SRR27160578_1_fastqc.zip
#         ├── [634K]  SRR27160578_2_fastqc.html
#         ├── [401K]  SRR27160578_2_fastqc.zip
#         ├── [634K]  SRR27160579_1_fastqc.html
#         ├── [395K]  SRR27160579_1_fastqc.zip
#         ├── [638K]  SRR27160579_2_fastqc.html
#         ├── [407K]  SRR27160579_2_fastqc.zip
#         ├── [636K]  SRR27160580_1_fastqc.html
#         ├── [395K]  SRR27160580_1_fastqc.zip
#         ├── [645K]  SRR27160580_2_fastqc.html
#         └── [416K]  SRR27160580_2_fastqc.zip
# 7 directories, 21 files

# Open the FastQC HTML reports in Firefox to visually inspect quality assessment results
firefox /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning/assembly/raw_qa/*.html

# Go back to the cleaning_assembly directory, create a directory for trimmed FastQ files & navigate into it
cd ..
mkdir trim
cd trim

# Check the version of Trimmomatic
trimmomatic -version
# Mine was 0.39

# Run Trimmomatic in paired-end mode on SRR27160580 files to trim low-quality reads with the following parameters:
# Parameters:
# SLIDINGWINDOW:5:30 trims reads when the average quality in a 5-base window drops below 30
# AVGQUAL:30 only keeps reads with an overall average quality of 30 or higher
trimmomatic PE -phred33 \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160580_1.fastq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160580_2.fastq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_1.paired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_1_unpaired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_2.paired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_2_unpaired.fq.gz \
 SLIDINGWINDOW:5:30 AVGQUAL:30
# Run comments: 
# Multiple cores found: Using 4 threads
# Input Read Pairs: 612478 Both Surviving: 496167 (81.01%) Forward Only Surviving: 63462 (10.36%) Reverse Only Surviving: 30182 (4.93%) Dropped: 22667 (3.70%)
# TrimmomaticPE: Completed successfully

# Run Trimmomatic for SRR27160579 with the same parameters
trimmomatic PE -phred33 \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160579_1.fastq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160579_2.fastq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_1.paired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_1_unpaired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_2.paired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_2_unpaired.fq.gz \
 SLIDINGWINDOW:5:30 AVGQUAL:30

# Run Trimmomatic for SRR27160578 with the same parameters
trimmomatic PE -phred33 \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160578_1.fastq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/raw_data/SRR27160578_2.fastq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_1.paired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_1_unpaired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_2.paired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_2_unpaired.fq.gz \
 SLIDINGWINDOW:5:30 AVGQUAL:30

# Combine unpaired reads from SRR27160580 (forward and reverse) into a single file
cat /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_1_unpaired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_2_unpaired.fq.gz \
 > /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_singletons.fq.gz

# Combine unpaired reads for SRR27160579 into a single file
cat /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_1_unpaired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_2_unpaired.fq.gz \
 > /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_singletons.fq.gz

# Combine unpaired reads for SRR27160578 into a single file
cat /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_1_unpaired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_2_unpaired.fq.gz \
 > /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_singletons.fq.gz

# Remove the individual unpaired read files now that they have been combined into singleton files
rm -v /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/*unpaired*
# removed '/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_1_unpaired.fq.gz'
# removed '/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_2_unpaired.fq.gz'
# removed '/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_1_unpaired.fq.gz'
# removed '/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_2_unpaired.fq.gz'
# removed '/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_1_unpaired.fq.gz'
# removed '/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_2_unpaired.fq.gz'

# Display the directory tree for the trim directory to confirm the combined files and trimmed outputs
tree -ah /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim
# [ 512]  /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim
# ├── [ 72M]  SRR27160578_1.paired.fq.gz
# ├── [ 71M]  SRR27160578_2.paired.fq.gz
# ├── [7.6M]  SRR27160578_singletons.fq.gz
# ├── [ 71M]  SRR27160579_1.paired.fq.gz
# ├── [ 70M]  SRR27160579_2.paired.fq.gz
# ├── [9.3M]  SRR27160579_singletons.fq.gz
# ├── [ 51M]  SRR27160580_1.paired.fq.gz
# ├── [ 50M]  SRR27160580_2.paired.fq.gz
# └── [8.2M]  SRR27160580_singletons.fq.gz
# 1 directory, 9 files

# Go back to cleaning_assembly directory, create a directory for assemblies & navigate into it
cd ..
mkdir asm
cd asm

# Check the version of SPAdes genome assembler
spades.py --version
# SPAdes genome assembler v3.15.5

# Run SPAdes assembly for SRR27160580 using paired and singleton trimmed reads; output assembly to a designated directory
spades.py \
 -1 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_1.paired.fq.gz \
 -2 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_2.paired.fq.gz \
 -s /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160580_singletons.fq.gz \
 -o /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/asm/spades_SRR27160580 \
 --only-assembler

# Count the number of contigs in the SRR27160580 assembly output
grep -c '>' /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/asm/spades/contigs.fasta 
# 239

# Run SPAdes assembly for SRR27160579 using its corresponding paired and singleton reads
spades.py \
 -1 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_1.paired.fq.gz \
 -2 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_2.paired.fq.gz \
 -s /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160579_singletons.fq.gz \
 -o /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/asm/spades_SRR27160579 \
 --only-assembler

# Count the number of contigs in the SRR27160579 assembly output
grep -c '>' /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/asm/spades_SRR27160579/contigs.fasta
# 290

# Run SPAdes assembly for SRR27160578 using its corresponding paired and singleton reads
spades.py \
 -1 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_1.paired.fq.gz \
 -2 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_2.paired.fq.gz \
 -s /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/trim/SRR27160578_singletons.fq.gz \
 -o /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/asm/spades_SRR27160578 \
 --only-assembler

# Count the number of contigs in the SRR27160578 assembly output
grep -c '>' /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/asm/spades_SRR27160578/contigs.fasta
# 423

# Create a directory for filtered contigs and navigate into it
mkdir contigs_filtering 
cd contigs_filtering 

# (Manually) rename and move the contigs.fasta files from each SPAdes assembly into this directory
ls -alh
# total 14M
# drwxrwxrwx 1 root root  512 Mar  5 17:26 .
# drwxrwxrwx 1 root root  512 Mar  5 17:26 ..
# -rwxrwxrwx 1 root root 4.6M Mar  5 17:23 contigs_SRR27160578.fasta
# -rwxrwxrwx 1 root root 4.6M Mar  5 17:12 contigs_SRR27160579.fasta
# -rwxrwxrwx 1 root root 4.6M Mar  5 16:57 contigs_SRR27160580.fasta

# Manually move the filter.contigs.py script into this directory and make it executable
chmod u+x *.py

# Use the filter.contigs.py script to filter the contigs from the SRR27160580 assembly based on a minimum coverage threshold of 10
./filter.contigs.py --infile /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/asm/spades_SRR27160580/contigs_SRR27160580.fasta --outfile filtered_assembly_SRR27160580.fna --discarded removed-contigs_SRR27160580.fa --cov 10 
# INFO: coverage quartiles of filtered contigs
#     (including cov filt)
#     25th=16.85
#     50th=17.69
#     75th=18.28
# INFO: coverage of filtered contigs
#     (including cov filt)
#     minimum=10.23
#     average=20.16
#     maximum=441.58
# INFO: 239 contigs input
# INFO: 4710660 bp input
# INFO: 33 contigs discarded
# INFO: 22070 bp discarded
# INFO: 206 contigs output
# INFO: 4688590 bp output

# Filter the contigs for SRR27160579 assembly with the same threshold
./filter.contigs.py --infile /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/asm/spades_SRR27160579/contigs_SRR27160579.fasta --outfile filtered_assembly_SRR27160579.fna --discarded removed-contigs_SRR27160579.fa --cov 10
# INFO: coverage quartiles of filtered contigs
#     (including cov filt)
#     25th=23.18
#     50th=24.04
#     75th=24.93
# INFO: coverage of filtered contigs
#     (including cov filt)
#     minimum=10.94
#     average=27.68
#     maximum=647.15
# INFO: 290 contigs input
# INFO: 4725152 bp input
# INFO: 84 contigs discarded
# INFO: 16871 bp discarded
# INFO: 206 contigs output
# INFO: 4708281 bp output

# Filter the contigs for SRR27160578 assembly with the same threshold
./filter.contigs.py --infile /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/cleaning_assembly/asm/spades_SRR27160578/contigs_SRR27160578.fasta --outfile filtered_assembly_SRR27160578.fna --discarded removed-contigs_SRR27160578.fa --cov 10
# INFO: coverage quartiles of filtered contigs
#     (including cov filt)
#     25th=24.06
#     50th=25.13
#     75th=25.92
# INFO: coverage of filtered contigs
#     (including cov filt)
#     minimum=10.74
#     average=26.76
#     maximum=634.55
# INFO: 423 contigs input
# INFO: 4728735 bp input
# INFO: 142 contigs discarded
# INFO: 27449 bp discarded
# INFO: 281 contigs output
# INFO: 4701286 bp output

# List the filtered assembly files to verify they exist and file sizes are the same/ similar
ls -alh *.fna
# -rwxrwxrwx 1 root root 4.6M Mar  5 17:46 filtered_assembly_SRR27160578.fna
# -rwxrwxrwx 1 root root 4.6M Mar  5 17:45 filtered_assembly_SRR27160579.fna
# -rwxrwxrwx 1 root root 4.6M Mar  5 17:44 filtered_assembly_SRR27160580.fna

# Deactivate the genome_hw environment now that cleaning and assembly are complete
conda deactivate 

# Navigate back to the main exercise directory and set up the fastANI analysis
# (We are now at /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5)
mkdir fastani 
cd fastani 

# Activate the fastani conda environment
conda activate fastani 

# Download the reference genome from NCBI
curl -O https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/020/735/925/GCF_020735925.1_ASM2073592v1/GCF_020735925.1_ASM2073592v1_genomic.fna.gz

# List files to confirm download
ls -lh
# total 1.3M
# -rwxrwxrwx 1 root root 1.3M Mar  5 18:09 GCF_020735925.1_ASM2073592v1_genomic.fna.gz

# Uncompress the reference genome file, keeping the original compressed file
gunzip -kv *.fna.gz
# GCF_020735925.1_ASM2073592v1_genomic.fna.gz:     72.0% -- created GCF_020735925.1_ASM2073592v1_genomic.fna

# (Manually) move the filtered assembly files into the current directory for fastANI analysis

# Display the first two lines of each .fna file to check headers
head -n 2 *.fna
# ==> GCF_020735925.1_ASM2073592v1_genomic.fna <==
# >NZ_CP085971.1 Bordetella parapertussis strain FDAARGOS_1541 chromosome, complete genome
# TCGCCCCGAATCCATGCAGAGAGACCGCTTTCGCCTATGCATCAACCCGTACTGCCCGCCTTCCTGATCGCCCGCTGGCT
# ==> filtered_assembly_SRR27160578.fna <==
# >contigs_SRR27160578_1 OrigDefln=NODE_1_length_185321_cov_27.137181
# GCGCCGGCGCGGCGCGGCCGATCGCGCACCCGCCCTACCATGCGGTCAGGCTGGTGCCGG
# ==> filtered_assembly_SRR27160579.fna <==
# >contigs_SRR27160579_1 OrigDefln=NODE_1_length_163238_cov_26.185964
# GCGCTGGGCCGGGGCGCGCTGCTGGCGCGGTGCGTCGTCGTAGCCACCGCCGTAACCGCC
# ==> filtered_assembly_SRR27160580.fna <==
# >contigs_SRR27160580_1 OrigDefln=NODE_1_length_185551_cov_19.232512
# CATTGTCGAGGGCATCAACAACACTATCAAGGTCATCAAGCGGCGCGCTTACGGCTACCG

# Display the last line of each .fna file to check file completeness
tail -n 1 *.fna
# ==> GCF_020735925.1_ASM2073592v1_genomic.fna <==
# GATTCAGCTTGCGGTCAGGGCCGTAAAACTCTGTATATTCCCAGGGT
# ==> filtered_assembly_SRR27160578.fna <==
# GGCCGGCGGCGCGCTGGACAACAT
# ==> filtered_assembly_SRR27160579.fna <==
# GGCTGGAGCAGCAGGCCCAGGCCGGCAACCGCCTGGGCCTGCTG
# ==> filtered_assembly_SRR27160580.fna <==
# GGCCTGACCCTGGATCCGGCCACCGGCATC

# Rename the reference genome file for ease of use
mv -v \
 GCF_020735925.1_ASM2073592v1_genomic.fna \
 reference.fna

# Run fastANI for each filtered assembly against the reference genome
fastANI \
  --query filtered_assembly_SRR27160580.fna \
  --ref reference.fna \
  --output FastANI_Output_SRR27160580.tsv

fastANI \
  --query filtered_assembly_SRR27160579.fna \
  --ref reference.fna \
  --output FastANI_Output_SRR27160579.tsv

fastANI \
  --query filtered_assembly_SRR27160578.fna \
  --ref reference.fna \
  --output FastANI_Output_SRR27160578.tsv

# Process the fastANI output for SRR27160580: calculate % aligned and alignment length, appending these as new columns
awk \
  '{alignment_percent = $4/$5*100} \
  {alignment_length = $4*3000} \
  {print $0 "\t" alignment_percent "\t" alignment_length}' \
  FastANI_Output_SRR27160580.tsv \
  > FastANI_Output_With_Alignment_SRR27160580.tsv

# Prepend a header to the processed output for SRR27160580
awk 'BEGIN \
  {print "Query\tReference\t%ANI\tNum_Fragments_Mapped\tTotal_Query_Fragments\t%Query_Aligned\tBasepairs_Query_Aligned"} \
  {print}' \
  FastANI_Output_With_Alignment_SRR27160580.tsv \
  > FastANI_Output_With_Alignment_With_Header_SRR27160580.tsv

# Align the processed output for SRR27160580 and display it
column -ts $'\t' FastANI_Output_With_Alignment_With_Header_SRR27160580.tsv | less -S

# Process the fastANI output for SRR27160579 similarly
awk \
  '{alignment_percent = $4/$5*100} \
  {alignment_length = $4*3000} \
  {print $0 "\t" alignment_percent "\t" alignment_length}' \
  FastANI_Output_SRR27160579.tsv \
  > FastANI_Output_With_Alignment_SRR27160579.tsv

# Prepend a header to the processed output for SRR27160579
awk 'BEGIN \
  {print "Query\tReference\t%ANI\tNum_Fragments_Mapped\tTotal_Query_Fragments\t%Query_Aligned\tBasepairs_Query_Aligned"} \
  {print}' \
  FastANI_Output_With_Alignment_SRR27160579.tsv \
  > FastANI_Output_With_Alignment_With_Header_SRR27160579.tsv

# Align the processed output for SRR27160579 and display it
column -ts $'\t' FastANI_Output_With_Alignment_With_Header_SRR27160579.tsv | less -S

# Process the fastANI output for SRR27160578 similarly
awk \
  '{alignment_percent = $4/$5*100} \
  {alignment_length = $4*3000} \
  {print $0 "\t" alignment_percent "\t" alignment_length}' \
  FastANI_Output_SRR27160578.tsv \
  > FastANI_Output_With_Alignment_SRR27160578.tsv

# Prepend a header to the processed output for SRR27160578
awk 'BEGIN \
  {print "Query\tReference\t%ANI\tNum_Fragments_Mapped\tTotal_Query_Fragments\t%Query_Aligned\tBasepairs_Query_Aligned"} \
  {print}' \
  FastANI_Output_With_Alignment_SRR27160578.tsv \
  > FastANI_Output_With_Alignment_With_Header_SRR27160578.tsv

# Align the processed output for SRR27160578 and display it
column -ts $'\t' FastANI_Output_With_Alignment_With_Header_SRR27160578.tsv | less -S

# Combine the fastANI output results from all three assemblies into one file, removing duplicate headers, and align columns
awk 'FNR==1 && NR!=1 {next} {print}' FastANI_Output_With_Alignment_With_Header_SRR27160580.tsv FastANI_Output_With_Alignment_With_Header_SRR27160579.tsv FastANI_Output_With_Alignment_With_Header_SRR27160578.tsv \
  | column -t -s $'\t' > fastani.tsv

# Deactivate the fastani conda environment
conda deactivate 

# Navigate back to the ex5 directory, create a directory for MLST analysis, and enter it
mkdir mlst
cd mlst 
# (Manually) move the filtered assembly files into the current mlst directory

# Activate the mlst conda environment
conda activate mlst

# Run MLST on all .fna files, align the output with column, and save to mlst.tsv
mlst *.fna | column -t -s $'\t' > mlst.tsv

# Deactivate the mlst environment
conda deactivate 

# Navigate back to the ex5 directory and set up the CheckM analysis
mkdir checkm
cd checkm
mkdir asm
cd asm 
# (Manually) move one filtered assembly file (SRR27160580) into the current checkm/asm directory
cd ..
mkdir db
cd db

# Download the CheckM database archive from Zenodo
curl -O https://zenodo.org/records/7401545/files/checkm_data_2015_01_16.tar.gz

# Extract the CheckM database archive
tar zxvf checkm_data_2015_01_16.tar.gz

# Add the CheckM database path to the bash configuration for future sessions
echo 'export CHECKM_DATA_PATH=/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/checkm/db' >> ~/.bashrc
source ~/.bashrc
echo "${CHECKM_DATA_PATH}"
# (This will output the path, mine was: "/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/checkm/db")

# Activate the checkm conda environment
conda activate checkm

# List available taxonomic groups in the CheckM database and filter for Bordetella entries
checkm taxon_list | grep Bordetella
#   genus     Bordetella                                              9            892              277
#   species   Bordetella holmesii                                     2            1523             215
#   species   Bordetella pertussis                                    2            1599             225

# Create a taxon set for the genus Bordetella and name it B.markers
checkm taxon_set genus "Bordetella" B.markers

# Run CheckM analyze on the filtered assembly in the checkm/asm directory using the B.markers taxon set
checkm \
  analyze \
  --threads 8 -x fna \
  B.markers \
  /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/ex5/checkm/asm \
  analyze_SRR27160580_output

# Install the tree utility if not already installed
apt install tree

# View the output directory structure of the CheckM analysis results
tree -ah analyze_SRR27160580_output/
# [ 512]  analyze_SRR27160580_output/
# ├── [ 512]  bins
# │   └── [ 512]  filtered_assembly_SRR27160580
# │       ├── [2.0M]  genes.faa
# │       ├── [1.1M]  genes.gff
# │       └── [5.4M]  hmmer.analyze.txt
# ├── [1.4K]  checkm.log
# └── [ 512]  storage
#     ├── [ 512]  aai_qa
#     │   └── [ 512]  filtered_assembly_SRR27160580
#     │       ├── [ 375]  PF02670.11.masked.faa
#     │       ├── [ 368]  PF03481.8.masked.faa
#     │       └── [ 225]  PF04760.10.masked.faa
#     ├── [ 453]  bin_stats.analyze.tsv
#     └── [ 85K]  checkm_hmm_info.pkl.gz
# 5 directories, 9 files

# Run CheckM quality assessment on the analysis output, saving results to quality.tsv
checkm \
  qa \
  --file quality.tsv \
  --out_format 1 \
  --threads 8 \
  B.markers \
  analyze_SRR27160580_output

# Check the size of the quality.tsv file
du -sh quality.tsv
# 4.0K    quality.tsv

# Display the contents of the quality.tsv file to review CheckM quality metrics
cat quality.tsv
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#   Bin Id                          Marker lineage   # genomes   # markers   # marker sets   0    1    2   3   4   5+   Completeness   Contamination   Strain heterogeneity
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------
#   filtered_assembly_SRR27160580   Bordetella (5)       9          892           277        6   883   3   0   0   0       99.57            0.13
# 0.00
# ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------

