# Create conda environment
conda create -n ex4_hw -y
# Activate conda environment 
conda activate ex4_hw
# Install required tools (prodigal, barrnap, bedtools and pigz)
conda install -c bioconda -c conda-forge prodigal barrnap bedtools pigz -y

# Verify installations 
prodigal -h
barrnap --version
#mine was v0.9
barrnap --help
bedtools --version
#mine was v2.31.1
bedtools --help
# Create directories for small subunit rRNA (ssu) and coding sequences (cds)
mkdir cds
mkdir ssu
ls #output:
# cds  cmds.sh  ssu
# Navigate into ssu directory 
cd ssu 
# Download the GCF_037966535.1 RefSeq assembly file
curl -O https://ftp.ncbi.nlm.nih.gov/genomes/all/GCF/037/966/535/GCF_037966535.1_ASM3796653v1/GCF_037966535.1_ASM3796653v1_genomic.fna.gz
# Extract file while keeping original
gunzip -k *.fna.gz
# Ensure file is there
ls -lh #output:
#total 2.8M
#-rwxrwxrwx 1 root root 2.2M Feb 11 14:17 GCF_037966535.1_ASM3796653v1_genomic.fna
#-rwxrwxrwx 1 root root 620K Feb 11 14:17 GCF_037966535.1_ASM3796653v1_genomic.fna.gz
# Run barrnap to predict 16S rRNA genes
barrnap GCF_037966535.1_ASM3796653v1_genomic.fna | grep "Name=16S_rRNA;product=16S ribosomal RNA" > 16S.gff
# Check the size of the 16S rRNA gene coordinates file
du -sh 16S.gff #0 : 16S.gff
# Extract 16S sequences using bedtools
bedtools getfasta -fi GCF_037966535.1_ASM3796653v1_genomic.fna -bed 16S.gff -s -fo 16S.fa
# Check the size of the extracted 16S rRNA sequence file
du -sh 16S.fa #4.0K : 16S.fa
# Verify extracted 16S rRNA sequence
# Check for FASTA header
grep '>' 16S.fa
#>NZ_JBBMMI010000032.1:350-1874(+)
# Display the full extracted sequence
cat 16S.fa
#>NZ_JBBMMI010000032.1:350-1874(+)
#GTGGAGAGTTTGATCCTGGCTCAGGACGAACGCTGGCGGCGTGCTTAACACATGCAAGTCGAACGGAAAGGCCTCAGCTTGCTGGGGTACTCGAGTGGCGAACGGGTGAGTAACACGTGGGTGATCTGCCCTCAACTTCGGGATAAGCTTGGGAAACTGGGTCTAATACCGGATAGGACCATGGTTTAGTGTTCATGGTGGAAAGCTTTATGTGGTTGGGGATGAGCTCGCGGCCTATCAGCTTGTTGGTGGGGTAATGGCCTACCAAGGCGGCGACGGGTAGCCGGCCTGAGAGGGTGTACGGCCACATTGGGACTGAGATACGGCCCAGACTCCTACGGGAGGCAGCAGTGGGGAATATTGCACAATGGGCGCAAGCCTGATGCAGCGACGCCGCGTGGGGGATGAAGGCCTTCGGGTTGTAAACTCCTTTCGCTACCGACGAAGCCCTTTGGGGTGACGGTAGGTGGAGAAGAAGCACCGGCTAACTACGTGCCAGCAGCCGCGGTAATACGTAGGGTGCGAGCGTTGTCCGGATTTACTGGGCGTAAAGAGCTCGTAGGTGGTTTGTCGCGTCGTCTGTGAAATTCCGGGGCTTAACTCCGGGCGTGCAGGCGATACGGGCATAACTTGAGTGCTGTAGGGGTAACTGGAATTCCTGGTGTAGCGGTGGAATGCGCAGATATCAGGAGGAACACCGATGGCGAAGGCAGGTTACTGGGCAGTTACTGACGCTGAGGAGCGAAAGCATGGGTAGCGAACAGGATTAGATACCCTGGTAGTCCATGCTGTAAACGGTGGGCGCTAGGTGTGAGCCTCTTCCACGGGGTTTGTGCCGTAGCTAACGCATTAAGCGCCCCGCCTGGGGAGTACGGCCGCAAGGCTAAAACTCAAAGGAATTGACGGGGGCCCGCACAAGCGGCGGAGCATGTGGATTAATTCGATGCAACGCGAAGAACCTTACCTGGGCTTGACATACACCAGATCGGCGCAGAGATGCGTTTTCCCTTTGTGGTTGGTGTACAGGTGGTGCATGGTTGTCGTCAGCTCGTGTCGTGAGATGTTGGGTTAAGTCCCGCAACGAGCGCAACCCTTGTCTTATGTTGCCAGCACGTGGTGGTGGGGACTCATGAGAGACTGCCGGGGTTAACTCGGAGGAAGGTGGGGATGACGTCAAATCATCATGCCCCTTATGTCCAGGGCTTCACACATGCTACAATGGTCGGTACAGTAGGTTGCGATACCGTGAGGTGGAGCTAATCCTTGTAAAGTCGGCCTTAGTTCGGATTGGGGTCTGCAACTCGACCCCATGAAGTCGGAGTCGCTAGTAATCGCAGATCAGCAACGCTGCGGTGAATACGTTCCCGGGCCTTGTACACACCGCCCGTCACGTCATGAAAGTTGGTAACACCCGAAAACCATGGCCTAACCCTTGTGGAGGGAGTGGTTGAAGGTGGGATTGGCGATTGGGACGAAGTCGTAACAAGGTAGCCGTACCGGAAGGTGCGGCTGGATCACCTCCTT
# Compress extracted sequence
pigz -9f 16S.fa
#Navigate to cds directory 
cd ..
cd cds 
# Run Prodigal for gene prediction
# -i input genome file
# -c ensures complete genes are predicted
# -m minimal threshold
# -f gff outputs results in GFF format
# -o cds.gff saves predicted CDS
# - `2>&1 | tee cds.log` captures both stderr & stdout in a log file
prodigal -i /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Gene_Pred_Anno_HW/ssu/GCF_037966535.1_ASM3796653v1_genomic.fna -c -m -f gff -o cds.gff 2>&1 | tee cds.log
# Ensure output files are present 
du -sh cds* #output: 
#496K    cds.gff
#4.0K    cds.log
# Compress output files
pigz -9f cds.gff cds.log
# Identified closest matches for 16S rRNA using BLASTN
# Went to https://blast.ncbi.nlm.nih.gov/Blast.cgi?PROGRAM=blastn&PAGE_TYPE=BlastSearch&LINK_LOC=blasthome 
# Selected 16S ribosomal RNA sequences (Bacteria and Archaeq) under rRNA/ITS databases
# Excluded Models (XM/XP) and Uncultured/environmental sample sequences
# Manually pasted 16S.fa.gz sequence in entry query box
# Ran BLASTN and saved the top 5 hits (sorted by max score) with full alignment details in 'top_ssu_alignments.xlsx'
#Compressed all files for submission
tar -czvf gene.tar.gz cmds.sh ssu/16S.fa.gz cds/cds.gff.gz cds/cds.log.gz top_ssu_alignments.xlsx
