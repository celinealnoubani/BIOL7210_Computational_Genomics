conda create -n genome_hw -y
#Created a new environment for HW assignment
conda activate genome_hw
#Activated new conda environment
conda install -c bioconda -c conda-forge entrez-direct sra-tools fastqc trimmomatic spades pigz tree -y
#Installed necessary tools from Bioconda and Conda-Forge channels
mkdir Genome_HW
#Created a directory to put HW directories in
cd Genome_HW
#Navigated into HW directory
mkdir raw_data
cd raw_data
#Made a directory for raw data & navigated into it
fasterq-dump --version
#Checked fasterq-dump version, mine was 3.2.0
prefetch SRR28480439
#Fetch Illumina PE FastQ data for SRR28480439
fasterq-dump SRR28480439 --outdir /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data --split-files --skip-technical
#Split and process the fetched data into FastQ files. Here was my output:
#spots read      : 492,430
#reads read      : 984,860
#reads written   : 984,860
du -sh /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/*.fastq
#Checked sizes of the downloaded FastQ files to verify expected data size. Here was my output:
#194M    /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/SRR28480439_1.fastq
#194M    /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/SRR28480439_2.fastq
pigz -9fv /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/*.fastq
#Compressed FastQ files using pigz. Here was my output:
#/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/SRR28480439_1.fastq to /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/SRR28480439_1.fastq.gz
#/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/SRR28480439_2.fastq to /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/SRR28480439_2.fastq.gz
tree -ah /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW
#Displayed directory structure & file sizes to ensure content is there. Here was my output:
#[ 512]  /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW
#├── [ 491]  cmds.sh
#└── [ 512]  raw_data
#    ├── [ 512]  SRR28480439
#    │   └── [ 72M]  SRR28480439.sra
#    ├── [ 49M]  SRR28480439_1.fastq.gz
#    └── [ 52M]  SRR28480439_2.fastq.gz

#3 directories, 4 files
mkdir raw_qa
#Made a raw_qa directory for quality assessment results (while in my Genome_HW directory)
fastqc --version
#Looked up fastqc version. Mine was FastQC v0.12.1
fastqc \
 --threads 2 \
 --outdir /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_qa \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/*.fastq.gz
#Ran FastQC on the compressed FastQ files
tree -ah /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW
#Displayed directory structure & file sizes to ensure content updated. This was my output:
#[ 512]  /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW
#├── [2.6K]  cmds.sh
#├── [ 512]  raw_data
#│   ├── [ 512]  SRR28480439
#│   │   └── [ 72M]  SRR28480439.sra
#│   ├── [ 49M]  SRR28480439_1.fastq.gz
#│   └── [ 52M]  SRR28480439_2.fastq.gz
#└── [ 512]  raw_qa
#    ├── [623K]  SRR28480439_1_fastqc.html
#    ├── [408K]  SRR28480439_1_fastqc.zip
#    ├── [628K]  SRR28480439_2_fastqc.html
#    └── [418K]  SRR28480439_2_fastqc.zip

#4 directories, 8 files
firefox /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_qa/*.html
#Viewed quality assessment results
mkdir trim
cd trim
#Created a directory for trimmed FastQ files & navigated to it.
trimmomatic -version
#Checked trimmomatic version. Mine was 0.39
trimmomatic PE -phred33 \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/SRR28480439_1.fastq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/raw_data/SRR28480439_2.fastq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/r1.paired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/r1_unpaired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/r2.paired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/r2_unpaired.fq.gz \
 HEADCROP:10 SLIDINGWINDOW:5:30 AVGQUAL:30 \
 1> trimmo.stdout.log \
 2> trimmo.stderr.log
#Used Trimmomatic to trim low-quality reads from the paired-end FastQ files.
#Parameters:
#HEADCROP:10 removes the first 10 bases from each read to eliminate low-quality bases
#SLIDINGWINDOW:5:30 trims reads when the average quality in a 5-base window drops below 30
#AVGQUAL:30 only keeps reads with an overall average quality of 30 or higher
cat /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/r1_unpaired.fq.gz \
 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/r2_unpaired.fq.gz \
 > /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/singletons.fq.gz
#Combined unpaired reads from both forward and reverse files into a single file
rm -v /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/*unpaired*
#Removed the unpaired read files since they've already been combined into the singletons file. This was the output:
#removed '/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/r1_unpaired.fq.gz'
#removed '/mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/r2_unpaired.fq.gz'
tree -ah /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim
#Displayed directory structure & file sizes to ensure content updated. This was my output:
#[ 512]  /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim
#├── [ 34M]  r1.paired.fq.gz
#├── [ 35M]  r2.paired.fq.gz
#├── [1.2M]  singletons.fq.gz
#├── [ 821]  trimmo.stderr.log
#└── [   0]  trimmo.stdout.log

#1 directory, 5 files
mkdir asm
cd asm
#Made a directory for assembly files while in Genome_HW dir & navigated into it.
spades.py --version
#Checked spades version and got v4.0.0
spades.py \
 -1 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/r1.paired.fq.gz \
 -2 /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/r2.paired.fq.gz \
 -s /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/trim/singletons.fq.gz \
 -o /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/asm/spades \
 --only-assembler \
 1> spades.stdout.txt \
 2> spades.stderr.txt
#Assembleed the genome with spades using trimmed paired-end & singleton reads.
grep -c '>' /mnt/c/Users/kayed/Documents/BIOL7210/Exercises/Genome_HW/asm/spades/contigs.fasta
#Counted the number of contigs in the spades assembly output. Got this output:
#202
conda install python=2.7 biopython -y
#Installed Python v2.7 with Biopython to be able to evaluate how filtering parameters affect output genome size
curl -O https://raw.githubusercontent.com/bacterial-genomics/genomics_scripts/refs/heads/main/filter.contigs.py
#Downloaded the filter.contigs.py script from the bacterial genomics GitHub repository
chmod u+x *.py
#Made the downloaded python script executable
./filter.contigs.py --infile asm/spades/contigs.fasta --outfile filtered_assembly.fna --discarded removed-contigs.fa 1> contig-filtering.stdout.log 2> contig-filtering.stderr.log --cov 10 --len 5000
#Used the filter.contigs.py script to filter contigs from the spades assembly based on coverage & length thresholds:
#cov 10 retains contigs w/ a minimum coverage of 10
#len 5000 retains contigs w/ a minimum length of 5000 bases
tail -n 20 contig-filtering.stderr.log
#Displayed the last 20 lines of the error log to review the filtering process. This was the output:
#INFO: coverage quartiles of filtered contigs
#    (including cov filt)
#    25th=22.39
#    50th=22.97
#    75th=23.52

#INFO: coverage of filtered contigs
#    (including cov filt)
#    minimum=19.47
#    average=27.58
#    maximum=228.79

#INFO: 202 contigs input
#INFO: 2247917 bp input
#INFO: 137 contigs discarded
#INFO: 69062 bp discarded
#INFO: 65 contigs output
#INFO: 2178855 bp output
