# Create Conda environment w/ FastANI
conda create -n fastani_env -c bioconda -y fastani
conda activate fastani_env
# Export environment dependencies to YAML file
conda env export > environment_fastani.yml
# Verify FastANI installed
fastANI --help
fastANI --version
# Install Fasten in same environment
conda install -c bioconda -y fasten
# Export all environment dependencies to a YAML file
conda env export > environment_fastani_fasten.yml
# Verify Fasten installed
fasten_clean --help
fasten_clean --version
# Install Pandas in same environment
conda install -y pandas
# Export all environment dependencies to a YAML file
conda env export > environment_fastani_fasten_pandas.yml
# Verify Pandas installed
python -c "import pandas as pd; print(pd.__all__)"
python -c "import pandas as pd; print(pd.__version__)"
# Write FastANI version to versions.txt
fastANI --version > versions.txt
# Append Fasten version to versions.txt
fasten_clean --version >> versions.txt
# Append Pandas version to versions.txt
python -c "import pandas as pd; print(pd.__version__)" >> versions.txt
